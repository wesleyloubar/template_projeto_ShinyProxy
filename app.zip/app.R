################################# SM PRICER 4.0################################# 
# source('ui/loginpage.R')

ui <- shinydashboard::dashboardPage( skin = 'black',
                                     # Dashboard header
                                     shinydashboard::dashboardHeader(title = "PSI5120"),
                                     shinydashboard::dashboardSidebar(
                                       br(),
                                       shiny::fluidPage(
                                         htmlOutput('boasvindas_output')
                                         
                                         ,br(),
                                         uiOutput('loginSM', align = 'center'),
                                         br(),
                                         # h3("Operador", align = 'center'),
                                         htmlOutput('operador_display'),
                                         br(), hr()),br(),
                                         uiOutput("sidebarpanel")
                                       # source('ui/sidebar_menu.R')
                                     ),


                                     ####    BODY    ####
                                     shinydashboard::dashboardBody(
                                       uiOutput("body")
                                       # ,shinydashboard::box(
                                       #   width = 11,
                                         ,shiny::fluidRow(
                                           # splitLayout(
                                           #   cellWidths = c("50%","50%"),
                                           #   cellArgs = list(style = "padding: 0px"),
                                           #   style = "border: 50px; padding: 100px;",
                                             # div(tags$img(src = 'logo_SM.jpeg', height = '40px', 
                                             #          width = '200px', alt = 'Logo SM', deleteFile = FALSE)
                                             # ,tags$img(src = 'logo_laraia2.png', height = '60px', 
                                             #          width = '200px', alt = 'Logo SM', deleteFile = FALSE), style = 'text-align: center;')
                                             
                                             
                                             uiOutput('logo_SM'),
                                             uiOutput('logo_laraia'),
                                             uiOutput('logos_rodape')
                                             #align = 'center'
                                           # )
                                         # ),
                                         ,shiny::h4(
                                           shiny::HTML('&copy'),
                                           htmlOutput('rodape_equipe'), align = 'center')
                                         )
                                      
                                       ))




###### SERVER #####
# Define server logic required to draw a histogram
server <- function(input, output, session){ 
  library(shinyalert)
  library(shinydashboard)
  library(shinyjs)
  library(shiny)
  library(plotly)
  # operador_id <<- '419BMlwDrTdlAZHySU2f'
  # source('data/funcoes_estudos.R')
  # source('data/funcoes_estudos.R', local = T, encoding = 'UTF8')[1]
  # source('ui/uidashboardPage.R', local = T, encoding = 'UTF8')[1]
  # source('data/funcoes_wesley.R', local = T, encoding = 'UTF8')[1]
  # source('functions/funcoes_usuarios.R', local = T, encoding = 'UTF8')[[1]]
  
  # Main login screen ####
  loginpage <-
    div(
      id = "loginpage",
      style = "width: 500px; max-width: 100%; margin: 0 auto; padding: 20px;
                 background-image: linear-gradient(to bottom, #003b52, #016473, #017687, #00879c, #02aac4,
                              #00879c, #017687, #016473, #003b52);",
      wellPanel(
        tags$h2("LOG IN", class = "text-center", style = "padding-top: 0;color:#333; font-weight:600;"),
        textInput(
          "userName",
          placeholder = "email",
          label = tagList(icon("user"), "Email")
        ),
        passwordInput(
          "passwd",
          placeholder = "senha",
          label = tagList(icon("unlock-alt"), "Senha")
        ),
        br(),
        div(
          style = "text-align: center;",
          actionButton(
            "login",
            "Entrar",
            style = "color: white; background-color:#3c8dbc;
                                 padding: 10px 15px; width: 150px; cursor: pointer;
                                 font-size: 18px; font-weight: 600;")
          
          # ,shinyjs::hidden(div(
          #   id = "nomatch"
          #   ,tags$p(
          #     "Oops! Email e/ou senha incorretos!",
          #     style = "color: red; font-weight: 600;
          #                                   padding-top: 5px;font-size:16px;",
          #     class = "text-center")
          # )
          )
        )
      )
    
  
  
  body_ui <-  shiny::fluidRow(
    shinydashboard::box(width = 12,
                        status = "success",
                        title = HTML('Gráficos'),
                        sidebarPanel(
                          selectInput('xcol','X Variable', names(mtcars)),
                          selectInput('ycol','Y Variable', names(mtcars)),
                          selected = names(mtcars)[[2]]),
                       
                          plotlyOutput('plot'),
                        
                        collapsible = TRUE,
                        solidHeader = TRUE,
                        br())

    )
  
  x <- reactive({
    mtcars[,input$xcol]
  })

  y <- reactive({
    mtcars[,input$ycol]
  })


  output$plot <- renderPlotly(
    plot1 <- plot_ly(
      x = x(),
      y = y(),
      type = 'scatter',
      mode = 'markers')
  )
  
  
  login <- FALSE
  USER <- reactiveValues(login = login)
  output$body <- renderUI({
    if (USER$login == TRUE) { body_ui } else {  loginpage  }
  })
  

  # output$sidebarpanel <- renderUI({ source('ui/sidebar_menu.R') })
  

  observe({
    if (USER$login == TRUE) {
      # updateTabItems(session, inputId = 'menu', selected = 'inicio')
      # output$rodape_equipe <- renderText(paste0(year(Sys.Date()), ' By LaraiaTech Dev. Team'))
      output$boasvindas_output <- renderText((paste0('
                                                 <h3 style="text-align: center;">Bem vindo(a)!</h3>
<h3 style="text-align: center;">Usu&aacute;rio:</h3>
<h3 style="text-align: center;">',strsplit(input$userName, '@')[[1]][1],'</h3>')))
      
    }else{
      if (!is.null(input$login)) {
        if (input$login > 0) {
          
          Username <- isolate(input$userName)
          Password <- isolate(input$passwd)
          
          email <- Username
          senha <- Password

            # df = validar_login(email, senha, session)
            
          usuarios <- data.frame(email = c('email1@gmail.com','email2@gmail.com','email3@gmail.com'),
                                 senha = c('123456','123456',"123456"))
          
          # email <- 'email1@gmail.com'
          # senha <- '123456'
            if(email %in% usuarios$email){
              
              df = usuarios[which(usuarios$email == email),]
              
              if(senha == df$senha[1]){
                USER$login = TRUE
              }else{
                shinyjs::delay(
                  3000,
                  shinyjs::toggle(
                    id = "nomatch",
                    anim = TRUE,
                    time = 1,
                    animType = "fade"
                  ))
                shinyalert("Oops!", "Senha incorreta!!!",
                           type = "error")
              }
              
            } else{
              shinyalert("Oops!", "Este usuário não está cadastrado na base de dados", 
                         type = "error")
            }
            # }else{
            #   shinyalert("Oops!", "Este usuário não está cadastrado na base de dados",
            #              type = "error")
            # }
          
        }}
    }
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)
